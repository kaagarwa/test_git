package main;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;


import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

public class Main {


private BufferedReader br;
public restaurantData restaurant_data;
private Gson gson;
private String file;
private Boolean exitStatus = false;
private Boolean changes = false;
public Scanner sc;



public static void main(String [] args){

	Boolean exceptionThrown = true;
	Main main = new Main();
	while(exceptionThrown) {
		try {
			main.br = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter input file:");
			
			main.file = main.br.readLine();
			BufferedReader bf = new BufferedReader(new FileReader(main.file));
			main.gson = new Gson();
			main.restaurant_data = main.gson.fromJson(bf, restaurantData.class);
			
		}
		catch (FileNotFoundException e) {
			System.out.println("That file could not be found.");
			exceptionThrown = true;
		}
		catch (IOException | JsonSyntaxException e){
			System.out.println("That file is not a well-formed JSON file.");
			exceptionThrown = true;
		}
		catch (NullPointerException e){
			System.out.println("That file is not a well-formed JSON file.");
			exceptionThrown = true;
		} 
		
		exceptionThrown = false;	
	}
		

		
		int num_orders = main.restaurant_data.Customers.size();
		
		for(int i = 0; i < num_orders; i++)
		{
			main.restaurant_data.Customers.get(i).order_ID = i;
			main.restaurant_data.Customers.get(i).start_time = 0;
			main.restaurant_data.Customers.get(i).completion_time = 0;
		}
		
		ExecutorService executor = Executors.newFixedThreadPool(num_orders);
		for(int i = 0; i < num_orders; i++)
		{
			executor.execute(new Order(main.restaurant_data.Customers.get(i)));
			
		}
		
		executor.shutdown();
		
		while (!executor.isTerminated())
		{
			Thread.yield();
		}
		
		Connection conn;
		Statement st;
		PreparedStatement ps;
		ResultSet rs;
		conn = null;
		st = null;
		ps = null;
		rs = null;
		
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1/order_data?user=root&password=root&useSSL=false");
			st = conn.createStatement();
		}
		
		catch (SQLException sqle) {
			System.out.println ("SQLException: " + sqle.getMessage());
		} 
		catch (ClassNotFoundException cnfe) {
			System.out.println ("ClassNotFoundException: " + cnfe.getMessage());
		}
		
		int order_num = 0;
		String start = "";
		String end = "";
		
		try 
		{
			ps = conn.prepareStatement("SELECT * FROM orders");
			rs = ps.executeQuery();
			while(rs.next())
			{
				order_num = rs.getInt("order_number");
				start = rs.getString("start_time");
				end = rs.getString("completion_time");
				System.out.println(order_num);
				System.out.println(start);
				System.out.println(end);
			}
		}
		
		catch (SQLException sqle) {
			System.out.println ("SQLException: " + sqle.getMessage());
		} 
		
		
		
		
		try {
			if (rs != null) {
				rs.close();
			}
			if (st != null) {
				st.close();
			}
			if (ps != null) {
				ps.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		}
		
		
	
}


}
