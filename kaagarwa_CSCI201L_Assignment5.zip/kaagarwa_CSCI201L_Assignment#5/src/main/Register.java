package main;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Register {
	
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss.SSS");
	LocalDateTime now = LocalDateTime.now();
	
	private Lock lock = new ReentrantLock();

	public synchronized void add(customers customer)
	{
		
		lock.lock();
		System.out.println("in register");
		System.out.println(dtf.format(now));
		try 
		{
			Thread.sleep(1500);
		}
		
		catch(InterruptedException IE)
		{
			System.out.println(IE.getMessage());
		}
		
		Thread.yield();
		lock.unlock();

	}
}
