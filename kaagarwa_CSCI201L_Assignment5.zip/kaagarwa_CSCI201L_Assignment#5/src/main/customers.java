package main;
import java.util.ArrayList;

public class customers {

	public ArrayList<String> order;
	public int order_ID;
	public int start_time;
	public int completion_time;
}
