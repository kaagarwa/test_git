package main;
import java.io.IOException;
import java.util.ArrayList;
import java.util.*;
import java.io.FileNotFoundException;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.annotations.*;

public class menu {
	
	@SerializedName("deep fryer") public static Set<String> deepfryer;
	@SerializedName("grill") public static Set<String> grill;
	@SerializedName("milkshake maker") public static Set<String> milkshake_maker;
	@SerializedName("drink machine") public static Set<String> drink_machine;
}
