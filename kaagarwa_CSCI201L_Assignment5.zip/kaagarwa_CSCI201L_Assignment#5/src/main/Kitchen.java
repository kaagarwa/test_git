package main;
import java.util.concurrent.Semaphore;

public class Kitchen extends menu {
	
	private static Semaphore deep_fryer = new Semaphore(4);
	private static Semaphore grill = new Semaphore(5);
	private static Semaphore m_maker = new Semaphore(2);
	private static Semaphore d_machine = new Semaphore(2);
	
	public void add(customers customer)
	{
		for(int i = 0; i < customer.order.size(); i++)
		{
			if(menu.deepfryer.contains(customer.order.get(i)))
			{
				try 
				{
					deep_fryer.acquire();
					Thread.sleep(2000);					
				}
				
				catch(InterruptedException IE)
				{
					System.out.println(IE.getMessage());
				}
				
				deep_fryer.release();
			}
			
			else if(menu.grill.contains(customer.order.get(i)))
			{
				try 
				{
					grill.acquire();
					Thread.sleep(5000);					
				}
				
				catch(InterruptedException IE)
				{
					System.out.println(IE.getMessage());
				}
				
				grill.release();
			}
			
			else if(menu.milkshake_maker.contains(customer.order.get(i)))
			{
				try 
				{
					m_maker.acquire();
					Thread.sleep(3000);					
				}
				
				catch(InterruptedException IE)
				{
					System.out.println(IE.getMessage());
				}
				
				m_maker.release();
			}
			
			else
			{
				try 
				{
					d_machine.acquire();
					Thread.sleep(2000);					
				}
				
				catch(InterruptedException IE)
				{
					System.out.println(IE.getMessage());
				}
				
				d_machine.release();
			}
		}
	}
}
