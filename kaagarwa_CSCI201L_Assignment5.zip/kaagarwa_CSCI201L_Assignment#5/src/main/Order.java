package main;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

public class Order implements Runnable {

	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss.SSS");
	LocalDateTime now = LocalDateTime.now();

	public customers customer;
	private Lock lock = new ReentrantLock();
	
	public Order(customers customer)
	{
		this.customer = customer;
	}
	
	private static Register register = new Register();
	private static Kitchen kitchen = new Kitchen();
	
	public void run()
	{
		lock.lock();
		
					
		register.add(customer);
		
		
		
		lock.unlock();
		
		kitchen.add(customer);
	}
}
