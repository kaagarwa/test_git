package restaurant_stats;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RestaurantStatistics {


		
		
		/*
		 * Constructor initializes connections
		 */
		public static void main (String args[])
		{
			Connection conn;
			Statement st;
			PreparedStatement ps;
			ResultSet rs;
			conn = null;
			st = null;
			ps = null;
			rs = null;
			
			try 
			{
				Class.forName("com.mysql.jdbc.Driver");
				conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1/order_data?user=root&password=root&useSSL=false");
				st = conn.createStatement();
			}
			
			catch (SQLException sqle) {
				System.out.println ("SQLException: " + sqle.getMessage());
			} 
			catch (ClassNotFoundException cnfe) {
				System.out.println ("ClassNotFoundException: " + cnfe.getMessage());
			}
			
			int order_num = 0;
			String start = "";
			String end = "";
			
			try 
			{
				ps = conn.prepareStatement("SELECT * FROM orders");
				rs = ps.executeQuery();
				while(rs.next())
				{
					order_num = rs.getInt("order_number");
					start = rs.getString("start_time");
					end = rs.getString("completion_time");
					System.out.println(order_num);
					System.out.println(start);
					System.out.println(end);
				}
			}
			
			catch (SQLException sqle) {
				System.out.println ("SQLException: " + sqle.getMessage());
			} 
			
			
			
			
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		};
}
