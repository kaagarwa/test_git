CREATE SCHEMA `order_data` ;
CREATE TABLE `order_data`.`orders` (
  `order_number` INT NOT NULL,
  `start_time` TIME(100) NULL,
  `completion_time` TIME(100) NULL,
  PRIMARY KEY (`order_number`));
